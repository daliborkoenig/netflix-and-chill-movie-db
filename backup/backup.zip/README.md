# Netflix & Chill movie DB

Built in Parcel, using HTML5, SASS, javascript, TMDB api and anime.js framework.

Small project for class to practice using external databases.

Search for content with searchbox. Click on the movie to open extended info. Same with popular movies and popular TV.

I hope you like it.

![Screenshot](./images/screenshot.png)
