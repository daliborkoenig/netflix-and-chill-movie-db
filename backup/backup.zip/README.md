# Netflix & Chill movie DB

Built in Parcel, using HTML5, SASS, javascript, TMDB api and anime.js framework.

Small project for class to practice using external databases.

I hope you like it.

![Screenshot](./images/screenshot.png)
